// Top-level build file. Android Studio will resolve these plugin
// versions automatically the first time you open this project
// (requires an internet connection on YOUR computer, not this sandbox).
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}

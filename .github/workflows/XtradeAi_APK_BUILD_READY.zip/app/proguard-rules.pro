# Tiada peraturan khas diperlukan buat masa ini — app ini cuma
# memuatkan WebView tempatan (dashboard.html), tiada refleksi/kod
# dinamik yang perlu dikecualikan daripada minification.

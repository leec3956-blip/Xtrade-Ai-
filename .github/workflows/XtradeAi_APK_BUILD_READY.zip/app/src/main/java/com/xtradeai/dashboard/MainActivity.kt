package com.xtradeai.dashboard

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * Xtrade Ai — skrin utama.
 *
 * Tidak ditulis semula dalam Kotlin/Compose secara berasingan: skrin ini
 * memuatkan terus fail dashboard.html yang sudah diuji dan diluluskan
 * dalam chat (checklist dinamik, gauge keyakinan, log aktiviti, status
 * sambungan MT5/broker). Ini mengelakkan dua salinan logik UI yang boleh
 * tercicir sinkron antara satu sama lain.
 *
 * Bila anda sedia sambungkan data robot SEBENAR (cTrader/MT5), cara yang
 * paling kemas ialah tambah satu WebView JavaScript Interface (@JavascriptInterface)
 * di sini yang menghantar data status/harga terkini ke fungsi JS
 * `applyState(...)` dalam dashboard.html — bukan tulis semula UI.
 */
class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Elak skrin gelap/tidur semasa robot "LIVE ANALYZING" dipaparkan.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/dashboard.html")
    }
}
